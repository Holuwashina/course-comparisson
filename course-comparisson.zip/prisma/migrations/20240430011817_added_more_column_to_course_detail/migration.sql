-- AlterTable
ALTER TABLE "CourseDetail" ADD COLUMN     "more" TEXT;
