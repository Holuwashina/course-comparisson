-- AlterTable
ALTER TABLE "CourseDetail" ALTER COLUMN "content" SET DATA TYPE TEXT;
