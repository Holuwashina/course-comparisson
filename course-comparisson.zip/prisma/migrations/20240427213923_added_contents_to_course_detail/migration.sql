-- AlterTable
ALTER TABLE "CourseDetail" ADD COLUMN     "contents" JSON;
