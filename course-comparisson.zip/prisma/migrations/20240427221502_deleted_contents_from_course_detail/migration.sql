/*
  Warnings:

  - You are about to drop the column `contents` on the `CourseDetail` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "CourseDetail" DROP COLUMN "contents";
