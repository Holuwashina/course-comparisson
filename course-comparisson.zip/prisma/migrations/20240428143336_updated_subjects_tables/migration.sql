-- AlterTable
ALTER TABLE "CapstoneSubject" ADD COLUMN     "link" VARCHAR(255);

-- AlterTable
ALTER TABLE "CoreSubject" ADD COLUMN     "link" VARCHAR(255);

-- AlterTable
ALTER TABLE "MajorCourse" ADD COLUMN     "link" VARCHAR(255);
