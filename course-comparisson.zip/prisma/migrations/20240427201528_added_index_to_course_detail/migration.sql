-- AlterTable
ALTER TABLE "CourseDetail" ADD COLUMN     "index" SERIAL NOT NULL;
