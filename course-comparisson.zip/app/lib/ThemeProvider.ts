"use client";
 
import { ThemeProvider } from "@material-tailwind/react";
 
export default ThemeProvider;